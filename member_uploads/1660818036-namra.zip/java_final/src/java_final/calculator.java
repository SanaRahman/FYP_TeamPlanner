package java_final;

import java.awt.Color;
import java.awt.Font;
import java.awt.SystemColor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;



public class calculator {
	JFrame frame;
	JTextField textField;
	public calculator() {
	
		frame = new JFrame();
		frame.setBounds(100, 100, 528, 381);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.WHITE);
		panel.setBounds(0, 0, 625, 342);
		frame.add(panel);
		panel.setLayout(null);
		
		JLabel answer = new JLabel();
		answer.setFont(new Font("Trebuchet MS", Font.BOLD, 14));
		answer.setForeground(new Color(204, 102, 204));
		answer.setBounds(39, 77, 419, 39);
		panel.add(answer);
		
		JButton cal7 = new JButton("7");
		cal7.setBackground(SystemColor.activeCaption);
		cal7.setFont(new Font("Tahoma", Font.BOLD, 18));
		cal7.setBounds(90, 122, 54, 39);
		panel.add(cal7);
		
		textField = new JTextField();
		textField.setFont(new Font("Sitka Subheading", Font.BOLD, 17));
		textField.setForeground(new Color(153, 0, 204));
		textField.setBounds(39, 31, 419, 39);
		panel.add(textField);
		textField.setColumns(10);
		
		JButton cal8 = new JButton("8");
		cal8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		cal8.setFont(new Font("Tahoma", Font.BOLD, 18));
		cal8.setBackground(SystemColor.activeCaption);
		cal8.setBounds(154, 122, 54, 39);
		panel.add(cal8);
		
		JButton cal9 = new JButton("9");
		cal9.setFont(new Font("Tahoma", Font.BOLD, 18));
		cal9.setBackground(SystemColor.activeCaption);
		cal9.setBounds(218, 122, 54, 39);
		panel.add(cal9);
		
		JButton cal4 = new JButton("4");
		cal4.setFont(new Font("Tahoma", Font.BOLD, 18));
		cal4.setBackground(SystemColor.activeCaption);
		cal4.setBounds(90, 172, 54, 39);
		panel.add(cal4);
		
		JButton cal5 = new JButton("5");
		cal5.setFont(new Font("Tahoma", Font.BOLD, 18));
		cal5.setBackground(SystemColor.activeCaption);
		cal5.setBounds(154, 172, 54, 39);
		panel.add(cal5);
		
		JButton cal6 = new JButton("6");
		cal6.setFont(new Font("Tahoma", Font.BOLD, 18));
		cal6.setBackground(SystemColor.activeCaption);
		cal6.setBounds(218, 172, 54, 39);
		panel.add(cal6);
		
		JButton cal1 = new JButton("1");
		cal1.setFont(new Font("Tahoma", Font.BOLD, 18));
		cal1.setBackground(SystemColor.activeCaption);
		cal1.setBounds(90, 222, 54, 39);
		panel.add(cal1);
		
		JButton cal2 = new JButton("2");
		cal2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		cal2.setFont(new Font("Tahoma", Font.BOLD, 18));
		cal2.setBackground(SystemColor.activeCaption);
		cal2.setBounds(154, 222, 54, 39);
		panel.add(cal2);
		
		JButton cal3 = new JButton("3");
		cal3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		cal3.setFont(new Font("Tahoma", Font.BOLD, 18));
		cal3.setBackground(SystemColor.activeCaption);
		cal3.setBounds(218, 222, 54, 39);
		panel.add(cal3);
		
		JButton cal0 = new JButton("0");
		cal0.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		cal0.setFont(new Font("Tahoma", Font.BOLD, 18));
		cal0.setBackground(SystemColor.activeCaption);
		cal0.setBounds(90, 272, 54, 39);
		panel.add(cal0);
		
		JButton cali = new JButton("i");
		cali.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		cali.setFont(new Font("Tahoma", Font.BOLD, 18));
		cali.setBackground(SystemColor.activeCaption);
		cali.setBounds(154, 272, 54, 39);
		panel.add(cali);
		
		JButton stop = new JButton("=");
		stop.setFont(new Font("Tahoma", Font.BOLD, 18));
		stop.setBackground(SystemColor.activeCaption);
		stop.setBounds(218, 272, 54, 39);
		panel.add(stop);
		
		JButton calmulti = new JButton("*");
		calmulti.setFont(new Font("Tahoma", Font.BOLD, 23));
		calmulti.setBackground(new Color(255, 215, 0));
		calmulti.setBounds(282, 122, 54, 39);
		panel.add(calmulti);
		
		JButton caldiv = new JButton("\u00F7");
		caldiv.setFont(new Font("Tahoma", Font.BOLD, 22));
		caldiv.setBackground(new Color(255, 215, 0));
		caldiv.setBounds(346, 122, 54, 39);
		panel.add(caldiv);
		
		JButton calsum = new JButton("+");
		calsum.setFont(new Font("Tahoma", Font.BOLD, 22));
		calsum.setBackground(new Color(255, 215, 0));
		calsum.setBounds(282, 172, 54, 39);
		panel.add(calsum);
		
		JButton calminus = new JButton("-");
		calminus.setFont(new Font("Tahoma", Font.BOLD, 22));
		calminus.setBackground(new Color(255, 215, 0));
		calminus.setBounds(346, 172, 54, 39);
		panel.add(calminus);
		
		JButton calleft = new JButton("(");
		calleft.setFont(new Font("Tahoma", Font.BOLD, 22));
		calleft.setBackground(new Color(255, 215, 0));
		calleft.setBounds(282, 222, 54, 39);
		panel.add(calleft);
		
		JButton calright = new JButton(")");
		calright.setFont(new Font("Tahoma", Font.BOLD, 22));
		calright.setBackground(new Color(255, 215, 0));
		calright.setBounds(346, 222, 54, 39);
		panel.add(calright);
		
		JButton calerase = new JButton("\u2190");
		calerase.setFont(new Font("Tahoma", Font.BOLD, 20));
		calerase.setBackground(new Color(255, 215, 0));
		calerase.setBounds(282, 272, 54, 39);
		panel.add(calerase);
		
		JButton calclear = new JButton("C");
		calclear.setFont(new Font("Tahoma", Font.BOLD, 22));
		calclear.setBackground(new Color(255, 215, 0));
		calclear.setBounds(346, 272, 54, 39);
		panel.add(calclear);
		frame.setVisible(true);
	}


	public static void main(String[] args) {
		// TODO Auto-generated method stub
calculator c=new calculator();

	}

}
